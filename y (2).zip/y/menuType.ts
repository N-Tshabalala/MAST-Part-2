export enum Course {
    STARTER = 'Starter',
    MAIN = 'Main',
    DESSERT = 'Dessert',
  }
  
  export interface MenuItem {
    id: number;
    dishName: string;
    description: string;
    course: Course;
    price: number;
  }
 
  