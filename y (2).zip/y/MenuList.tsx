
import React from 'react';
import { View, Text } from 'react-native';
import MenuItemComponent from './MenuItemComponent'; // Now it should work!
import { MenuItem } from './menuType';

interface MenuListProps {
  menuItems: MenuItem[];
}

const MenuList = ({ menuItems }: MenuListProps) => {
  return (
    <View>
      <Text>Menu ({menuItems.length} items)</Text>
      {menuItems.map((menuItem) => (
        <MenuItemComponent key={menuItem.dishName} menuItem={menuItem} />
      ))}
    </View>
  );
};

export default MenuList;


