

import { MenuItem, Course } from './menuType';


let menuItemId = 0;
const menuData: MenuItem[] = [];

const addMenuItem = (menuItem: MenuItem) => {
  menuItemId++;
  menuData.push({ ...menuItem, id: menuItemId });
};

const getMenuItems = () => menuData;

export { addMenuItem, getMenuItems };
