
import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import { Picker } from '@react-native-picker/picker';

import { addMenuItem } from './menuData';
import { Course, MenuItem } from './menuType';



const MenuForm = () => {
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState(Course.STARTER);
  const [price, setPrice] = useState(0);

  const handleSubmit = () => {
    addMenuItem({
      dishName,
      description,
      course,
      price,
    } as MenuItem);
    setDishName('');
    setDescription('');
    setCourse(Course.STARTER);
    setPrice(0);
  };

  return (
    <View>
      <Text>Dish Name:</Text>
      <TextInput value={dishName} onChangeText={(text) => setDishName(text)} />
      <Text>Description:</Text>
      <TextInput value={description} onChangeText={(text) => setDescription(text)} />
      <Text>Course:</Text>
      <Picker
        selectedValue={course}
        onValueChange={(itemValue: Course) => setCourse(itemValue)}
      >
        <Picker.Item label={Course.STARTER} value={Course.STARTER} />
        <Picker.Item label={Course.MAIN} value={Course.MAIN} />
        <Picker.Item label={Course.DESSERT} value={Course.DESSERT} />
      </Picker>
      <Text>Price:</Text>
      <Picker
        selectedValue={price.toString()}
        onValueChange={(itemValue: string) => setPrice(Number(itemValue))}
      >
        <Picker.Item label="R100" value="100" />
        <Picker.Item label="R200" value="200" />
        <Picker.Item label="R300" value="300" />
      </Picker>
      <Button title="Add Menu Item" onPress={handleSubmit} />
    </View>
  );
};

export default MenuForm;

