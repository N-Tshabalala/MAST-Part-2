import React from 'react';
import { View, ImageBackground, StyleSheet } from 'react-native';
import MenuList from './MenuList';
import MenuForm from './MenuForm';
import { getMenuItems } from './menuData';

const App = () => {
  const menuItems = getMenuItems();

  return (
    <ImageBackground
      source={require('./PCP 2.png')}
      style={styles.container}
    >
     
        <MenuForm />
        <MenuList menuItems={menuItems} />
      
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  
container: {
  flex: 1,
  flexDirection: 'column',
},


  
content: {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
  padding: 20,


  },
  dishInfoContainer: {
    marginBottom: 20,
  },
  dishInfo: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    padding: 20,
  },
  dishName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  bottomContainer: {
    padding: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    
  },
});

export default App;









