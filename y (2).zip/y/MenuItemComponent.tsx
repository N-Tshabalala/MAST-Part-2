
import React from 'react';
import { View, Text } from 'react-native';
import { MenuItem } from './menuType';

interface MenuItemComponentProps {
  menuItem: MenuItem;
}

const MenuItemComponent = ({ menuItem }: MenuItemComponentProps) => {
  return (
    <View>
      <Text>{menuItem.dishName}</Text>
      <Text>{menuItem.description}</Text>
      <Text>Course: {menuItem.course}</Text>
      <Text>Price: ${menuItem.price}</Text>
    </View>
  );
};

export default MenuItemComponent;
